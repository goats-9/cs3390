# README

To run the source code in this directory:

1. Unzip the entire zip file.
2. Open the source code using Jupyter Notebook or VS Code (with the Jupyter Notebook Extension).
3. Click on "Run All" to run all cells in the source.
